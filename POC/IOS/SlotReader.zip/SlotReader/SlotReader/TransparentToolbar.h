//
//  TransparentToolbar.h
//  SlotReader
//
//  Created by User on 3/23/16.
//  Copyright © 2016 User. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TransparentToolbar : UIToolbar

@end
