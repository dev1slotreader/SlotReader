//
//  UIViewController+NavigationBar.m
//  SlotReader
//
//  Created by Anastasiia on 23.06.16.
//  Copyright © 2016 User. All rights reserved.
//

#import "UIViewController+NavigationBar.h"

@implementation UIViewController (NavigationBar)

@end
