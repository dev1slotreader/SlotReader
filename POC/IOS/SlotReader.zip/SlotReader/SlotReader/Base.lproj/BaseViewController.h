//
//  BaseViewController.h
//  SlotReader
//
//  Created by Anastasiia on 24.06.16.
//  Copyright © 2016 User. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"
#import "BoardViewController.h"
#import "SWRevealViewController.h"

@interface BaseViewController : UIViewController

@end
