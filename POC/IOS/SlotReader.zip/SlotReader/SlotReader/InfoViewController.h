//
//  InfoViewController.h
//  SlotReader
//
//  Created by User on 4/4/16.
//  Copyright © 2016 User. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface InfoViewController : UIViewController

@property (weak, nonatomic) IBOutlet UIBarButtonItem *showMenuButton;

@end
