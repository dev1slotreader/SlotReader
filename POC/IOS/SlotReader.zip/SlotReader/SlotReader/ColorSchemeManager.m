//
//  ColorSchemeManager.m
//  SlotReader
//
//  Created by Anastasiia on 23.06.16.
//  Copyright © 2016 User. All rights reserved.
//

#import "ColorSchemeManager.h"

@implementation ColorSchemeManager

@end
