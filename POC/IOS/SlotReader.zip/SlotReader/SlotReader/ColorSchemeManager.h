//
//  ColorSchemeManager.h
//  SlotReader
//
//  Created by Anastasiia on 23.06.16.
//  Copyright © 2016 User. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ColorSchemeManager : NSObject

@end
