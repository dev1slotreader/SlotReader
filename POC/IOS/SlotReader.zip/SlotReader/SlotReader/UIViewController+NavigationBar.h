//
//  UIViewController+NavigationBar.h
//  SlotReader
//
//  Created by Anastasiia on 23.06.16.
//  Copyright © 2016 User. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIViewController (NavigationBar)


@end
