//
//  ViewController.m
//  SlotReader
//
//  Created by User on 3/11/16.
//  Copyright © 2016 User. All rights reserved.
//

#import "CenterViewController.h"
#import "WordPickerHelperViewController.h"
#import "MenuPanelViewController.h"
@import QuartzCore;

@interface CenterViewController () <MenuPanelViewControllerDelegate, UIDynamicAnimatorDelegate>{
	WordPickerHelperViewController *pickerHelper;
	SWRevealViewController *revealViewController;
	MenuPanelViewController *menuPanelViewController;
	NSDictionary *allWordsForCurrentLanguage;
}

@end

@implementation CenterViewController

- (void)viewDidLoad {
	[super viewDidLoad];
	pickerHelper = [[WordPickerHelperViewController alloc] init];
	menuPanelViewController = [[MenuPanelViewController alloc] init];

	self.picker.delegate = pickerHelper;
	self.picker.dataSource = pickerHelper;
	
	[self getDataFromStorage];	

	self.navigationController.navigationBar.backgroundColor = [UIColor redColor];
	[self.navigationController.navigationBar setBarTintColor:[UIColor colorWithRed:(181/255.0) green:(252/255.0) blue:(251/255.0) alpha:1]];
	self.navigationItem.title = @"Slot Reader";

	
	revealViewController = self.revealViewController;
	if ( revealViewController )
	{
		
		[self.showMenuButton setTarget: self.revealViewController];
		[self.showMenuButton setAction: @selector( revealToggle: )];
		[self.view addGestureRecognizer:self.revealViewController.panGestureRecognizer];
	}	
}

- (void) viewDidAppear:(BOOL)animated{
	
}

- (void)didReceiveMemoryWarning {
	[super didReceiveMemoryWarning];
	// Dispose of any resources that can be recreated.
}

#pragma mark - Getting data

- (void) getDataFromStorage {
	NSError *error = nil;
	NSString *filePath = [[NSBundle mainBundle] pathForResource:@"slot_reader_source" ofType:@"txt"];
	NSURL *url = [NSURL fileURLWithPath:filePath];

	NSData *data = [NSData dataWithContentsOfFile:filePath];
	NSDictionary *jsonData = [NSJSONSerialization JSONObjectWithData:data
															 options:kNilOptions
															   error:&error];
	if (error != nil) {
		UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Error"
														message:@"Couldn't load the data"
													   delegate:self
											  cancelButtonTitle:@"OK"
											  otherButtonTitles:nil];
		[alert show];
	} else {
		NSLog(@"%@", [[NSUserDefaults standardUserDefaults] objectForKey:@"language"]);
		allWordsForCurrentLanguage = [jsonData objectForKey:@"words"];
		self.alphabet = [NSArray arrayWithArray:[[jsonData objectForKey:@"words"] objectForKey:[NSString stringWithFormat:@"%@1",[[NSUserDefaults standardUserDefaults] objectForKey:@"language"]]]];
		NSLog(@"OK");
	}
}

#pragma mark - Displaying letters and words

- (void) setNumberOfLetters:(NSNumber *)numberOfLetters andLanguage: (NSString *) language {
	[pickerHelper setNumberOfLettersToShow:numberOfLetters andLanguage:nil];
	[self.picker reloadAllComponents];
}

- (void) displayWord:(NSString *)word animated:(BOOL)animated {
	pickerHelper.pickerWorkingAutomatically = YES;
	for (NSUInteger i = 0; i < [word length]; i++) {
		NSString *letter = [NSString stringWithFormat:@"%c", [word characterAtIndex:i]];
		[self displayLetter:letter
				atComponent:i
				   animated:animated];
	}
	pickerHelper.pickerWorkingAutomatically = NO;
}

- (void) displayLetter:(NSString *)letter atComponent:(NSUInteger)component animated:(BOOL)animated {
	NSUInteger row;
	if (animated){
		NSUInteger selectedRow = [self.picker selectedRowInComponent:component];
		row = selectedRow + ([self.alphabet count] - selectedRow % [self.alphabet count]) + [self.alphabet indexOfObject:letter];
	}
	else
		row = ((UINT16_MAX) / (2 * [self.alphabet count]) * [self.alphabet count]) + [self.alphabet indexOfObject:letter];
	[self.picker selectRow:row
					 inComponent:component
						animated:animated];
}

- (IBAction)wordChanged:(id)sender {

}


- (IBAction)changeNumberOfLettersToShow:(id)sender {
	int numberOfLetters = (int)((UIBarButtonItem *)sender).tag;
	switch (numberOfLetters) {
    case 0:
		[self setNumberOfLetters:[NSNumber numberWithInt: 10] andLanguage:nil];
		break;
    default:
		[self setNumberOfLetters:[NSNumber numberWithInt: numberOfLetters] andLanguage:nil];
		break;
	}
	[self showTheFirstWordForNumberOfLetters:numberOfLetters];
}

- (void) showTheFirstWordForNumberOfLetters: (int) numberOfLetters{
	NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
	[defaults setObject:[NSArray arrayWithObjects:[NSNumber numberWithInt:numberOfLetters], [NSNumber numberWithInt:0], nil] forKey:@"currentPositon"];
	NSArray *words = [allWordsForCurrentLanguage objectForKey:[NSString stringWithFormat:@"%@%d",[[NSUserDefaults standardUserDefaults] objectForKey:@"language"], numberOfLetters]];
	[self displayWord:[[words objectAtIndex:0] uppercaseString] animated:YES];
}


@end
